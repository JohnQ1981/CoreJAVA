package day22inheritance;

public class Runner {

	public static void main(String[] args) {


		
		Honda h1 = new Honda();
		
		
		System.out.println("============");
		
		Honda h2 = new Honda("Civic");
		
		System.out.println("============");
		
		Car c1 = new Car();
		//c1. 
		
		
		System.out.println("============");
		
		Car c2 = new Car("Toyota");
		System.out.println("============");
		Vehicle v1= new Vehicle(5);
		

	}

}

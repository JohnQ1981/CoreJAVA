package day22inheritance;

public class Vehicle {

	public int price =20;
	
	public Vehicle(int price) {
		
		
		System.out.println("Vehicle with Parameter");
	}
	
}

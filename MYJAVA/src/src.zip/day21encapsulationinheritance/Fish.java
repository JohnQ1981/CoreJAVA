package day21encapsulationinheritance;
			//child       //parent
public class Fish extends Animal  {

		public Fish() {
			System.out.println("Fish Constructor");
		}
	public static void main(String[] args) {
		
	}
	
	
	public void liveUnderWater() {
		
		System.out.println("Fish live underwater");
	}
	
	
}

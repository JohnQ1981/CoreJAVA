package day21encapsulationinheritance;

public class AdvancedCal extends NormalCal{

	
		public static void exponent(double a, double b) {
			
			System.out.println(Math.pow(a, b));
			
		}
}

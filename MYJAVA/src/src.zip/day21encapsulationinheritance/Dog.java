package day21encapsulationinheritance;

public class Dog extends Mammal {

		public Dog() {
			System.out.println("Dog constructor");
		}
	public static void main(String[] args) {
		
	}
	
	
	public void bark() {
		System.out.println("Dogs bark");
	}
	public void smellWell() {
		
		System.out.println("Dogs smell well");
	}
}

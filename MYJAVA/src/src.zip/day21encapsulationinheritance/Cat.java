package day21encapsulationinheritance;

public class Cat extends Mammal  {

	public Cat () {
		System.out.println("Cat constructor");
	}
	public static void main(String[] args) {
		
	}

		public void meow() {
			System.out.println("Cats meow");
		}
}

package day18passbyvaluepassbyreferencedatetime;

public class AcMo03 {

	
		private String privateName= "Ali";
		protected static String protectedName = "Veli";
		String defaultName = "Mary";
		public String publicName = "Angie";
		
	public static void main(String[] args) {


		

	}

}

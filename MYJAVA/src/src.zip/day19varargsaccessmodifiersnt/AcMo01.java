package day19varargsaccessmodifiersnt;

public class AcMo01 {
	// instance variables below
		private int privateAge = 23;
		protected int protectedAge = 25;
		 int defaultAge = 27;// default 
		 public int publicAge = 29;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

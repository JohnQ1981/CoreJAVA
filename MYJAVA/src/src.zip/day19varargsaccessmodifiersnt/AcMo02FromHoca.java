package day19varargsaccessmodifiersnt;

public class AcMo02FromHoca {

	public static void main(String[] args) {


		
		

	}

}
